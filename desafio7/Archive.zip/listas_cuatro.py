from listas_uno import lista

lista_1 = []

for i in lista:
    if i[4] == True:
        print(i[3])
        print(i[0])



