numero_usuario = int(input("Ingrese un número\n"))
i = 0

while i <= numero_usuario:
    if i % 2 ==0:
        print(i)
    i += 1