numero_usuario = int(input("Ingrese un número\n"))
i = 1
texto =""
while i <= numero_usuario:
    texto = texto+str(i)
    print(texto)
    i += 1